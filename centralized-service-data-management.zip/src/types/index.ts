// Types for the application

export interface User {
  id: string;
  username: string;
  role: 'admin' | 'viewer';
}

// Répertoire types
export interface RepertoireEntry {
  id: string;
  nom: string;
  fix: string;
  mobile: string;
  mail: string;
  adresse: string;
  obs: string;
}

export interface EntrepriseEntry {
  id: string;
  nom: string;
  entreprise: string;
  natureIntervention: string;
  date: string;
  obs: string;
}

// Boucle types
export interface BoucleEntry {
  id: string;
  position: string;
  slotA: string;
  exA: string;
  positionB: string;
  slotB: string;
  exB: string;
  obs: string;
}

export interface BoucleSection {
  id: string;
  title: string;
  entries: BoucleEntry[];
}

// FMX types
export interface FMXEntry {
  id: string;
  position: string;
  exA: string;
  exB: string;
}

export interface FMXSection {
  id: string;
  title: string;
  entries: FMXEntry[];
}

// Fibre/ODF types
export interface FibreEntry {
  id: string;
  paires: string;
  exA: string;
  numeroOdfA: string;
  etageA: string;
  exB: string;
  numeroOdfB: string;
  etageB: string;
  date: string;
  intervenant: string;
}

export interface FibreSection {
  letter: string;
  entries: FibreEntry[];
}

// Énergie types
export interface EtatEntry {
  id: string;
  marque: string;
  dateMES: string;
  etat: string;
  observations: string;
}

export interface InterventionGEEntry {
  id: string;
  date: string;
  test: string;
  index: string;
  batterie: string;
  fuel: string;
  huile: string;
  eau: string;
  observations: string;
}

export interface DerangementGEEntry {
  id: string;
  date: string;
  coupureSecteur: string;
  defautDemarrage: string;
  anomalie: string;
  serviceAvise: string;
  observations: string;
}

export interface InterventionCLIMEntry {
  id: string;
  marque: string;
  date: string;
  inValue: string;
  outValue: string;
  observations: string;
}

export interface DerangementCLIMEntry {
  id: string;
  marque: string;
  date: string;
  natureDefaut: string;
  anomalie: string;
  serviceAvise: string;
  observations: string;
}

export interface InterventionONDULAIREntry {
  id: string;
  date: string;
  maintenance: string;
  batterie: string;
  observations: string;
}

export interface DerangementONDULAIREntry {
  id: string;
  date: string;
  coupureSecteur: string;
  defautDemarrage: string;
  anomalie: string;
  serviceAvise: string;
  observations: string;
}

export interface InterventionBATTERIEEntry {
  id: string;
  date: string;
  test: string;
  observations: string;
}

export interface DerangementBATTERIEEntry {
  id: string;
  date: string;
  impact: string;
  anomalie: string;
  serviceAvise: string;
  observations: string;
}

export interface InterventionATELIEREntry {
  id: string;
  date: string;
  maintenance: string;
  consommation: string;
  observations: string;
}

export interface DerangementATELIEREntry {
  id: string;
  date: string;
  coupureSecteur: string;
  defautModule: string;
  anomalie: string;
  serviceAvise: string;
  observations: string;
}

export interface EnergieSection {
  id: string;
  type: 'GE' | 'CLIM' | 'ONDULAIRE' | 'BATTERIE' | 'ATELIER';
  etat: EtatEntry[];
  intervention: any[];
  derangement: any[];
}

// Visite types
export interface IntervenantEntry {
  id: string;
  nom: string;
  service: string;
  natureIntervention: string;
  date: string;
  obs: string;
}

export interface VisiteurEntry {
  id: string;
  nom: string;
  structure: string;
  natureVisite: string;
  date: string;
  obs: string;
}

// RH types
export interface PersonnelEntry {
  id: string;
  nom: string;
  matricule: string;
  grade: string;
  dateRecrutement: string;
  email: string;
  adresse: string;
  mobile: string;
}

export interface FormationEntry {
  id: string;
  nom: string;
  formation: string;
  date: string;
  lieu: string;
  besoin: string;
}

export interface CongeEntry {
  id: string;
  dateDebut: string;
  dateFin: string;
  duree: string;
  reste: string;
  observations: string;
}

export interface PersonnelConge {
  id: string;
  nom: string;
  conges: CongeEntry[];
}

export type SectionType = 
  | 'repertoire' 
  | 'boucle' 
  | 'fmx' 
  | 'fibre' 
  | 'energie' 
  | 'visite' 
  | 'rh';
