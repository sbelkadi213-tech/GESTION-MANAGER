import { useState } from 'react';
import { useApp } from '../context/AppContext';
import DataTable from '../components/DataTable';

type TabType = 'intervenants' | 'visiteurs' | 'entreprise';

export default function VisitePage() {
  const { intervenants, setIntervenants, visiteurs, setVisiteurs, entrepriseEntries, setEntrepriseEntries } = useApp();
  const [activeTab, setActiveTab] = useState<TabType>('intervenants');

  const intervenantColumns = [
    { key: 'nom', label: 'Nom' },
    { key: 'service', label: 'Service' },
    { key: 'natureIntervention', label: 'Nature Intervention' },
    { key: 'date', label: 'Date' },
    { key: 'obs', label: 'Observations' },
  ];

  const visiteurColumns = [
    { key: 'nom', label: 'Nom' },
    { key: 'structure', label: 'Structure' },
    { key: 'natureVisite', label: 'Nature Visite' },
    { key: 'date', label: 'Date' },
    { key: 'obs', label: 'Observations' },
  ];

  const entrepriseColumns = [
    { key: 'nom', label: 'Nom' },
    { key: 'entreprise', label: 'Entreprise' },
    { key: 'natureIntervention', label: 'Nature Intervention' },
    { key: 'date', label: 'Date' },
    { key: 'obs', label: 'Observations' },
  ];

  const tabs = [
    { id: 'intervenants' as TabType, label: 'INTERVENANTS', icon: '👷' },
    { id: 'visiteurs' as TabType, label: 'VISITEURS', icon: '🚶' },
    { id: 'entreprise' as TabType, label: 'Entreprise AT Prestataire', icon: '🏢' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 bg-gradient-to-br from-teal-500 to-teal-600 rounded-xl shadow-lg">
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
          </svg>
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Intervenants et Visiteurs</h1>
          <p className="text-gray-500">Gestion des interventions et des visites</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="border-b border-gray-200">
          <nav className="flex -mb-px">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? 'border-teal-500 text-teal-600 bg-teal-50/50'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                <span>{tab.icon}</span>
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'intervenants' && (
            <DataTable
              columns={intervenantColumns}
              data={intervenants}
              onUpdate={setIntervenants}
              searchPlaceholder="Rechercher parmi les intervenants..."
            />
          )}
          {activeTab === 'visiteurs' && (
            <DataTable
              columns={visiteurColumns}
              data={visiteurs}
              onUpdate={setVisiteurs}
              searchPlaceholder="Rechercher parmi les visiteurs..."
            />
          )}
          {activeTab === 'entreprise' && (
            <DataTable
              columns={entrepriseColumns}
              data={entrepriseEntries}
              onUpdate={setEntrepriseEntries}
              searchPlaceholder="Rechercher parmi les prestataires..."
            />
          )}
        </div>
      </div>
    </div>
  );
}
