import { useState } from 'react';
import { useApp } from '../context/AppContext';
import DataTable from '../components/DataTable';

export default function FibrePage() {
  const { fibreSections, setFibreSections } = useApp();
  const [selectedLetter, setSelectedLetter] = useState<string>('A');
  const [searchTerm, setSearchTerm] = useState('');

  const columns = [
    { key: 'paires', label: 'Paires' },
    { key: 'exA', label: 'EX A' },
    { key: 'numeroOdfA', label: 'N° ODF' },
    { key: 'etageA', label: 'Étage' },
    { key: 'exB', label: 'EX B' },
    { key: 'numeroOdfB', label: 'N° ODF' },
    { key: 'etageB', label: 'Étage' },
    { key: 'date', label: 'Date' },
    { key: 'intervenant', label: 'Intervenant' },
  ];

  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

  const filteredLetters = searchTerm
    ? alphabet.filter(letter => {
        const section = fibreSections.find(s => s.letter === letter);
        return section?.entries.some(entry =>
          Object.values(entry).some(val => 
            String(val).toLowerCase().includes(searchTerm.toLowerCase())
          )
        );
      })
    : alphabet;

  const currentSection = fibreSections.find(s => s.letter === selectedLetter);

  const handleUpdateEntries = (entries: any[]) => {
    const updated = fibreSections.map(s =>
      s.letter === selectedLetter ? { ...s, entries } : s
    );
    setFibreSections(updated);
  };

  const getEntryCount = (letter: string) => {
    const section = fibreSections.find(s => s.letter === letter);
    return section?.entries.length || 0;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl shadow-lg">
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Fibre et ODF</h1>
          <p className="text-gray-500">Gestion des connexions fibre optique et ODF</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <div className="relative max-w-md">
            <input
              type="text"
              placeholder="Rechercher dans les fibres..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
            />
            <svg className="absolute left-3 top-3 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
        </div>

        {/* Alphabet Navigation */}
        <div className="p-4 bg-gradient-to-r from-gray-50 to-gray-100 border-b border-gray-200">
          <div className="flex flex-wrap gap-2 justify-center">
            {alphabet.map((letter) => {
              const count = getEntryCount(letter);
              const isSelected = selectedLetter === letter;
              const isFiltered = filteredLetters.includes(letter);
              
              return (
                <button
                  key={letter}
                  onClick={() => setSelectedLetter(letter)}
                  className={`relative w-10 h-10 rounded-lg font-semibold text-sm transition-all ${
                    isSelected
                      ? 'bg-orange-500 text-white shadow-md'
                      : isFiltered
                      ? 'bg-white text-gray-700 hover:bg-orange-100 border border-gray-200'
                      : 'bg-gray-100 text-gray-400 hover:bg-gray-200'
                  }`}
                >
                  {letter}
                  {count > 0 && (
                    <span className={`absolute -top-1 -right-1 w-4 h-4 text-xs rounded-full flex items-center justify-center ${
                      isSelected ? 'bg-white text-orange-500' : 'bg-orange-500 text-white'
                    }`}>
                      {count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Letter Content */}
        <div className="p-6">
          <div className="mb-4 flex items-center gap-2">
            <span className="text-lg font-semibold text-gray-700">Lettre:</span>
            <span className="px-4 py-1 bg-orange-100 text-orange-700 rounded-lg font-bold text-xl">
              {selectedLetter}
            </span>
            <span className="text-gray-500">
              ({currentSection?.entries.length || 0} entrées)
            </span>
          </div>

          {currentSection && (
            <DataTable
              columns={columns}
              data={currentSection.entries}
              onUpdate={handleUpdateEntries}
              searchPlaceholder={`Rechercher dans la section ${selectedLetter}...`}
            />
          )}
        </div>
      </div>
    </div>
  );
}
