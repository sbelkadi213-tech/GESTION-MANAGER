import { useState } from 'react';
import { useApp } from '../context/AppContext';
import DataTable from '../components/DataTable';
import { BoucleSection } from '../types';

type TabType = 'local' | 'regional';

export default function BouclePage() {
  const { isAdmin, boucleLocal, setBoucleLocal, boucleRegional, setBoucleRegional } = useApp();
  const [activeTab, setActiveTab] = useState<TabType>('local');
  const [expandedSection, setExpandedSection] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState<string | null>(null);
  const [newTitle, setNewTitle] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const columns = [
    { key: 'position', label: 'Position' },
    { key: 'slotA', label: 'Slot' },
    { key: 'exA', label: 'EX A' },
    { key: 'positionB', label: 'Position' },
    { key: 'slotB', label: 'Slot' },
    { key: 'exB', label: 'EX B' },
    { key: 'obs', label: 'Observations' },
  ];

  const currentData = activeTab === 'local' ? boucleLocal : boucleRegional;
  const setCurrentData = activeTab === 'local' ? setBoucleLocal : setBoucleRegional;

  const filteredSections = currentData.filter(section =>
    section.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    section.entries.some(entry =>
      Object.values(entry).some(val => 
        String(val).toLowerCase().includes(searchTerm.toLowerCase())
      )
    )
  );

  const handleTitleEdit = (sectionId: string, title: string) => {
    setEditingTitle(sectionId);
    setNewTitle(title);
  };

  const handleTitleSave = (sectionId: string) => {
    const updated = currentData.map(s =>
      s.id === sectionId ? { ...s, title: newTitle } : s
    );
    setCurrentData(updated);
    setEditingTitle(null);
  };

  const handleAddSection = () => {
    const newSection: BoucleSection = {
      id: Math.random().toString(36).substr(2, 9),
      title: `Nouvelle Boucle ${currentData.length + 1}`,
      entries: []
    };
    setCurrentData([...currentData, newSection]);
  };

  const handleDeleteSection = (sectionId: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette section ?')) {
      setCurrentData(currentData.filter(s => s.id !== sectionId));
    }
  };

  const handleUpdateEntries = (sectionId: string, entries: any[]) => {
    const updated = currentData.map(s =>
      s.id === sectionId ? { ...s, entries } : s
    );
    setCurrentData(updated);
  };

  const tabs = [
    { id: 'local' as TabType, label: 'BOUCLE LOCAL', icon: '🔌' },
    { id: 'regional' as TabType, label: 'BOUCLE RÉGIONAL', icon: '🌐' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl shadow-lg">
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
          </svg>
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Boucle</h1>
          <p className="text-gray-500">Gestion des connexions de boucle locale et régionale</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="border-b border-gray-200">
          <nav className="flex -mb-px">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? 'border-emerald-500 text-emerald-600 bg-emerald-50/50'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                <span>{tab.icon}</span>
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6 space-y-4">
          <div className="flex flex-col sm:flex-row gap-3 justify-between items-start sm:items-center">
            <div className="relative flex-1 w-full sm:max-w-md">
              <input
                type="text"
                placeholder="Rechercher dans les boucles..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
              />
              <svg className="absolute left-3 top-3 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            {isAdmin && (
              <button
                onClick={handleAddSection}
                className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
                Ajouter une section
              </button>
            )}
          </div>

          <div className="space-y-4">
            {filteredSections.map((section) => (
              <div key={section.id} className="border border-gray-200 rounded-xl overflow-hidden">
                <div 
                  className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-gray-100 cursor-pointer hover:from-gray-100 hover:to-gray-150 transition-colors"
                  onClick={() => setExpandedSection(expandedSection === section.id ? null : section.id)}
                >
                  <div className="flex items-center gap-3">
                    <svg 
                      className={`w-5 h-5 text-gray-500 transition-transform ${expandedSection === section.id ? 'rotate-90' : ''}`} 
                      fill="none" 
                      stroke="currentColor" 
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                    {editingTitle === section.id ? (
                      <input
                        type="text"
                        value={newTitle}
                        onChange={(e) => setNewTitle(e.target.value)}
                        onClick={(e) => e.stopPropagation()}
                        className="px-3 py-1 border border-emerald-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
                        autoFocus
                      />
                    ) : (
                      <h3 className="font-semibold text-gray-800">{section.title}</h3>
                    )}
                    <span className="text-sm text-gray-500">({section.entries.length} entrées)</span>
                  </div>
                  {isAdmin && (
                    <div className="flex gap-2" onClick={(e) => e.stopPropagation()}>
                      {editingTitle === section.id ? (
                        <button
                          onClick={() => handleTitleSave(section.id)}
                          className="px-3 py-1.5 bg-emerald-600 text-white rounded-md text-sm hover:bg-emerald-700"
                        >
                          Sauver
                        </button>
                      ) : (
                        <button
                          onClick={() => handleTitleEdit(section.id, section.title)}
                          className="px-3 py-1.5 bg-amber-500 text-white rounded-md text-sm hover:bg-amber-600"
                        >
                          Renommer
                        </button>
                      )}
                      <button
                        onClick={() => handleDeleteSection(section.id)}
                        className="px-3 py-1.5 bg-red-500 text-white rounded-md text-sm hover:bg-red-600"
                      >
                        Supprimer
                      </button>
                    </div>
                  )}
                </div>
                
                {expandedSection === section.id && (
                  <div className="p-4 border-t border-gray-200">
                    <DataTable
                      columns={columns}
                      data={section.entries}
                      onUpdate={(entries) => handleUpdateEntries(section.id, entries)}
                      searchPlaceholder="Rechercher dans cette section..."
                    />
                  </div>
                )}
              </div>
            ))}
          </div>

          {filteredSections.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              Aucune section trouvée
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
