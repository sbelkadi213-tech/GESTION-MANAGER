import { useState } from 'react';
import { useApp } from '../context/AppContext';
import DataTable from '../components/DataTable';
import { PersonnelConge, CongeEntry } from '../types';

type TabType = 'personnel' | 'formation' | 'conge';

export default function RHPage() {
  const { isAdmin, personnel, setPersonnel, formations, setFormations, conges, setConges } = useApp();
  const [activeTab, setActiveTab] = useState<TabType>('personnel');
  const [expandedPersonnel, setExpandedPersonnel] = useState<string | null>(null);
  const [newPersonName, setNewPersonName] = useState('');

  const personnelColumns = [
    { key: 'nom', label: 'Nom' },
    { key: 'matricule', label: 'Matricule' },
    { key: 'grade', label: 'Grade' },
    { key: 'dateRecrutement', label: 'Date Recrutement' },
    { key: 'email', label: 'Email' },
    { key: 'adresse', label: 'Adresse' },
    { key: 'mobile', label: 'Mobile' },
  ];

  const formationColumns = [
    { key: 'nom', label: 'Nom' },
    { key: 'formation', label: 'Formation' },
    { key: 'date', label: 'Date' },
    { key: 'lieu', label: 'Lieu' },
    { key: 'besoin', label: 'Besoin' },
  ];

  const congeColumns = [
    { key: 'dateDebut', label: 'Date Début' },
    { key: 'dateFin', label: 'Date Fin' },
    { key: 'duree', label: 'Durée' },
    { key: 'reste', label: 'Reste' },
    { key: 'observations', label: 'Observations' },
  ];

  const tabs = [
    { id: 'personnel' as TabType, label: 'PERSONNEL', icon: '👥' },
    { id: 'formation' as TabType, label: 'FORMATION', icon: '📚' },
    { id: 'conge' as TabType, label: 'CONGÉ', icon: '📅' },
  ];

  const handleAddPersonnelConge = () => {
    if (!newPersonName.trim()) return;
    const newPerson: PersonnelConge = {
      id: Math.random().toString(36).substr(2, 9),
      nom: newPersonName,
      conges: []
    };
    setConges([...conges, newPerson]);
    setNewPersonName('');
  };

  const handleDeletePersonnelConge = (id: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce personnel ?')) {
      setConges(conges.filter(c => c.id !== id));
    }
  };

  const handleUpdateConges = (personnelId: string, newConges: CongeEntry[]) => {
    const updated = conges.map(c =>
      c.id === personnelId ? { ...c, conges: newConges } : c
    );
    setConges(updated);
  };

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center p-8 bg-red-50 rounded-xl border border-red-200">
          <svg className="w-16 h-16 mx-auto text-red-500 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
          </svg>
          <h2 className="text-xl font-bold text-red-700 mb-2">Accès Restreint</h2>
          <p className="text-red-600">Cette section est réservée à l'administrateur.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 bg-gradient-to-br from-rose-500 to-rose-600 rounded-xl shadow-lg">
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
          </svg>
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Ressources Humaines</h1>
          <p className="text-gray-500">Gestion du personnel, formations et congés</p>
        </div>
        <span className="ml-auto px-3 py-1 bg-red-100 text-red-700 rounded-full text-sm font-medium">
          Admin uniquement
        </span>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="border-b border-gray-200">
          <nav className="flex -mb-px">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? 'border-rose-500 text-rose-600 bg-rose-50/50'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                <span>{tab.icon}</span>
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'personnel' && (
            <DataTable
              columns={personnelColumns}
              data={personnel}
              onUpdate={setPersonnel}
              searchPlaceholder="Rechercher dans le personnel..."
            />
          )}
          
          {activeTab === 'formation' && (
            <DataTable
              columns={formationColumns}
              data={formations}
              onUpdate={setFormations}
              searchPlaceholder="Rechercher dans les formations..."
            />
          )}
          
          {activeTab === 'conge' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-3 justify-between items-start sm:items-center">
                <div className="flex-1 flex gap-2">
                  <input
                    type="text"
                    placeholder="Nom du personnel..."
                    value={newPersonName}
                    onChange={(e) => setNewPersonName(e.target.value)}
                    className="flex-1 px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-500 focus:border-rose-500"
                  />
                  <button
                    onClick={handleAddPersonnelConge}
                    className="flex items-center gap-2 px-4 py-2.5 bg-rose-600 text-white rounded-lg hover:bg-rose-700 transition-colors"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                    </svg>
                    Ajouter
                  </button>
                </div>
              </div>

              <div className="space-y-4">
                {conges.map((personnelConge) => (
                  <div key={personnelConge.id} className="border border-gray-200 rounded-xl overflow-hidden">
                    <div 
                      className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-gray-100 cursor-pointer hover:from-gray-100 hover:to-gray-150 transition-colors"
                      onClick={() => setExpandedPersonnel(expandedPersonnel === personnelConge.id ? null : personnelConge.id)}
                    >
                      <div className="flex items-center gap-3">
                        <svg 
                          className={`w-5 h-5 text-gray-500 transition-transform ${expandedPersonnel === personnelConge.id ? 'rotate-90' : ''}`} 
                          fill="none" 
                          stroke="currentColor" 
                          viewBox="0 0 24 24"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                        <div className="w-10 h-10 bg-rose-100 rounded-full flex items-center justify-center">
                          <span className="text-rose-600 font-semibold">
                            {personnelConge.nom.charAt(0).toUpperCase()}
                          </span>
                        </div>
                        <h3 className="font-semibold text-gray-800">{personnelConge.nom}</h3>
                        <span className="text-sm text-gray-500">({personnelConge.conges.length} congés)</span>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeletePersonnelConge(personnelConge.id);
                        }}
                        className="px-3 py-1.5 bg-red-500 text-white rounded-md text-sm hover:bg-red-600"
                      >
                        Supprimer
                      </button>
                    </div>
                    
                    {expandedPersonnel === personnelConge.id && (
                      <div className="p-4 border-t border-gray-200">
                        <DataTable
                          columns={congeColumns}
                          data={personnelConge.conges}
                          onUpdate={(newConges) => handleUpdateConges(personnelConge.id, newConges)}
                          searchPlaceholder="Rechercher dans les congés..."
                        />
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {conges.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  Aucun personnel enregistré pour les congés
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
