import { useState } from 'react';
import { useApp } from '../context/AppContext';
import DataTable from '../components/DataTable';

type EnergieType = 'GE' | 'CLIM' | 'ONDULAIRE' | 'BATTERIE' | 'ATELIER';
type MatiereType = 'etat' | 'intervention' | 'derangement';

export default function EnergiePage() {
  const { energieSections, setEnergieSections } = useApp();
  const [selectedType, setSelectedType] = useState<EnergieType>('GE');
  const [selectedMatiere, setSelectedMatiere] = useState<MatiereType>('etat');
  const [searchTerm] = useState('');

  const energieTypes: { id: EnergieType; label: string; icon: string }[] = [
    { id: 'GE', label: 'GE', icon: '⚡' },
    { id: 'CLIM', label: 'CLIM', icon: '❄️' },
    { id: 'ONDULAIRE', label: 'ONDULAIRE', icon: '🔄' },
    { id: 'BATTERIE', label: 'BATTERIE', icon: '🔋' },
    { id: 'ATELIER', label: 'ATELIER ÉNERGIE', icon: '🏭' },
  ];

  const matiereTypes: { id: MatiereType; label: string; icon: string }[] = [
    { id: 'etat', label: 'ÉTAT', icon: '📊' },
    { id: 'intervention', label: 'INTERVENTION', icon: '🔧' },
    { id: 'derangement', label: 'DÉRANGEMENT', icon: '⚠️' },
  ];

  const getColumns = (type: EnergieType, matiere: MatiereType) => {
    if (matiere === 'etat') {
      return [
        { key: 'marque', label: 'MARQUE' },
        { key: 'dateMES', label: 'Date MES' },
        { key: 'etat', label: 'État' },
        { key: 'observations', label: 'Observations' },
      ];
    }

    if (matiere === 'intervention') {
      switch (type) {
        case 'GE':
          return [
            { key: 'date', label: 'Date' },
            { key: 'test', label: 'Test' },
            { key: 'index', label: 'Index' },
            { key: 'batterie', label: 'Batterie' },
            { key: 'fuel', label: 'Fuel' },
            { key: 'huile', label: 'Huile' },
            { key: 'eau', label: 'Eau' },
            { key: 'observations', label: 'Observations' },
          ];
        case 'CLIM':
          return [
            { key: 'marque', label: 'MARQUE' },
            { key: 'date', label: 'Date' },
            { key: 'inValue', label: 'IN' },
            { key: 'outValue', label: 'OUT' },
            { key: 'observations', label: 'Observations' },
          ];
        case 'ONDULAIRE':
          return [
            { key: 'date', label: 'Date' },
            { key: 'maintenance', label: 'Maintenance' },
            { key: 'batterie', label: 'Batterie' },
            { key: 'observations', label: 'Observations' },
          ];
        case 'BATTERIE':
          return [
            { key: 'date', label: 'Date' },
            { key: 'test', label: 'Test' },
            { key: 'observations', label: 'Observations' },
          ];
        case 'ATELIER':
          return [
            { key: 'date', label: 'Date' },
            { key: 'maintenance', label: 'Maintenance' },
            { key: 'consommation', label: 'Consommation' },
            { key: 'observations', label: 'Observations' },
          ];
      }
    }

    if (matiere === 'derangement') {
      switch (type) {
        case 'GE':
        case 'ONDULAIRE':
          return [
            { key: 'date', label: 'Date' },
            { key: 'coupureSecteur', label: 'Coupure Secteur' },
            { key: 'defautDemarrage', label: 'Défaut Démarrage' },
            { key: 'anomalie', label: 'Anomalie' },
            { key: 'serviceAvise', label: 'Service Avisé' },
            { key: 'observations', label: 'Observations' },
          ];
        case 'CLIM':
          return [
            { key: 'marque', label: 'Marque' },
            { key: 'date', label: 'Date' },
            { key: 'natureDefaut', label: 'Nature Défaut' },
            { key: 'anomalie', label: 'Anomalie' },
            { key: 'serviceAvise', label: 'Service Avisé' },
            { key: 'observations', label: 'Observations' },
          ];
        case 'BATTERIE':
          return [
            { key: 'date', label: 'Date' },
            { key: 'impact', label: 'Impact' },
            { key: 'anomalie', label: 'Anomalie' },
            { key: 'serviceAvise', label: 'Service Avisé' },
            { key: 'observations', label: 'Observations' },
          ];
        case 'ATELIER':
          return [
            { key: 'date', label: 'Date' },
            { key: 'coupureSecteur', label: 'Coupure Secteur' },
            { key: 'defautModule', label: 'Défaut Module' },
            { key: 'anomalie', label: 'Anomalie' },
            { key: 'serviceAvise', label: 'Service Avisé' },
            { key: 'observations', label: 'Observations' },
          ];
      }
    }

    return [];
  };

  const currentSection = energieSections.find(s => s.type === selectedType);
  const currentData = currentSection ? currentSection[selectedMatiere] : [];
  const columns = getColumns(selectedType, selectedMatiere);

  const handleUpdateData = (newData: any[]) => {
    const updated = energieSections.map(s => {
      if (s.type === selectedType) {
        return { ...s, [selectedMatiere]: newData };
      }
      return s;
    });
    setEnergieSections(updated);
  };

  const filteredData = currentData.filter((item: any) =>
    columns.some(col => 
      String(item[col.key] || '').toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-xl shadow-lg">
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Énergie et Environnement</h1>
          <p className="text-gray-500">Gestion des équipements énergétiques et environnementaux</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        {/* Equipment Type Tabs */}
        <div className="border-b border-gray-200 bg-gradient-to-r from-gray-50 to-gray-100">
          <nav className="flex flex-wrap -mb-px p-2">
            {energieTypes.map((type) => (
              <button
                key={type.id}
                onClick={() => setSelectedType(type.id)}
                className={`flex items-center gap-2 px-4 py-3 mx-1 text-sm font-medium rounded-lg transition-all ${
                  selectedType === type.id
                    ? 'bg-yellow-500 text-white shadow-md'
                    : 'text-gray-600 hover:bg-yellow-100 hover:text-yellow-700'
                }`}
              >
                <span>{type.icon}</span>
                {type.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Matiere Type Tabs */}
        <div className="border-b border-gray-200">
          <nav className="flex -mb-px">
            {matiereTypes.map((matiere) => (
              <button
                key={matiere.id}
                onClick={() => setSelectedMatiere(matiere.id)}
                className={`flex items-center gap-2 px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                  selectedMatiere === matiere.id
                    ? 'border-yellow-500 text-yellow-600 bg-yellow-50/50'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                <span>{matiere.icon}</span>
                {matiere.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Content */}
        <div className="p-6">
          <div className="mb-4 flex items-center gap-3">
            <span className="px-3 py-1.5 bg-yellow-100 text-yellow-700 rounded-lg font-semibold">
              {selectedType}
            </span>
            <span className="text-gray-400">→</span>
            <span className="px-3 py-1.5 bg-gray-100 text-gray-700 rounded-lg font-medium">
              {selectedMatiere.toUpperCase()}
            </span>
            <span className="text-gray-500">
              ({filteredData.length} entrées)
            </span>
          </div>

          <DataTable
            columns={columns}
            data={currentData}
            onUpdate={handleUpdateData}
            searchPlaceholder={`Rechercher dans ${selectedType} - ${selectedMatiere}...`}
          />
        </div>
      </div>
    </div>
  );
}
