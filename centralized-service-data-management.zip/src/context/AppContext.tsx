import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, RepertoireEntry, EntrepriseEntry, BoucleSection, FMXSection, FibreSection, EnergieSection, IntervenantEntry, VisiteurEntry, PersonnelEntry, FormationEntry, PersonnelConge } from '../types';

interface AppContextType {
  user: User | null;
  login: (username: string, password: string) => boolean;
  logout: () => void;
  isAdmin: boolean;
  
  // Répertoire
  repertoireLocal: RepertoireEntry[];
  setRepertoireLocal: (data: RepertoireEntry[]) => void;
  repertoireRegional: RepertoireEntry[];
  setRepertoireRegional: (data: RepertoireEntry[]) => void;
  entrepriseEntries: EntrepriseEntry[];
  setEntrepriseEntries: (data: EntrepriseEntry[]) => void;
  
  // Boucle
  boucleLocal: BoucleSection[];
  setBoucleLocal: (data: BoucleSection[]) => void;
  boucleRegional: BoucleSection[];
  setBoucleRegional: (data: BoucleSection[]) => void;
  
  // FMX
  fmxLocal: FMXSection[];
  setFmxLocal: (data: FMXSection[]) => void;
  fmxRegional: FMXSection[];
  setFmxRegional: (data: FMXSection[]) => void;
  
  // Fibre
  fibreSections: FibreSection[];
  setFibreSections: (data: FibreSection[]) => void;
  
  // Énergie
  energieSections: EnergieSection[];
  setEnergieSections: (data: EnergieSection[]) => void;
  
  // Visite
  intervenants: IntervenantEntry[];
  setIntervenants: (data: IntervenantEntry[]) => void;
  visiteurs: VisiteurEntry[];
  setVisiteurs: (data: VisiteurEntry[]) => void;
  
  // RH
  personnel: PersonnelEntry[];
  setPersonnel: (data: PersonnelEntry[]) => void;
  formations: FormationEntry[];
  setFormations: (data: FormationEntry[]) => void;
  conges: PersonnelConge[];
  setConges: (data: PersonnelConge[]) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const generateId = () => Math.random().toString(36).substr(2, 9);

// Default data
const defaultRepertoireLocal: RepertoireEntry[] = [
  { id: generateId(), nom: 'Ahmed Ben Ali', fix: '71000001', mobile: '20000001', mail: 'ahmed@email.com', adresse: 'Tunis', obs: '' },
  { id: generateId(), nom: 'Mohamed Trabelsi', fix: '71000002', mobile: '20000002', mail: 'mohamed@email.com', adresse: 'Sfax', obs: '' },
];

const defaultRepertoireRegional: RepertoireEntry[] = [
  { id: generateId(), nom: 'Ali Mansouri', fix: '72000001', mobile: '21000001', mail: 'ali@email.com', adresse: 'Sousse', obs: '' },
];

const defaultEntreprise: EntrepriseEntry[] = [
  { id: generateId(), nom: 'Tech Solutions', entreprise: 'Tech Corp', natureIntervention: 'Maintenance', date: '2024-01-15', obs: '' },
];

const defaultBoucleLocal: BoucleSection[] = [
  {
    id: generateId(),
    title: 'Boucle Locale 1',
    entries: [
      { id: generateId(), position: 'POS-001', slotA: 'A1', exA: 'EX-A1', positionB: 'POS-002', slotB: 'B1', exB: 'EX-B1', obs: '' },
    ]
  },
  {
    id: generateId(),
    title: 'Boucle Locale 2',
    entries: []
  }
];

const defaultBoucleRegional: BoucleSection[] = [
  {
    id: generateId(),
    title: 'Boucle Régionale 1',
    entries: [
      { id: generateId(), position: 'POS-R001', slotA: 'A1', exA: 'EX-RA1', positionB: 'POS-R002', slotB: 'B1', exB: 'EX-RB1', obs: '' },
    ]
  }
];

const defaultFmxLocal: FMXSection[] = [
  {
    id: generateId(),
    title: 'FMX1',
    entries: [
      { id: generateId(), position: 'FMX-001', exA: 'EX-A', exB: 'EX-B' },
    ]
  },
  {
    id: generateId(),
    title: 'FMX2',
    entries: []
  }
];

const defaultFmxRegional: FMXSection[] = [
  {
    id: generateId(),
    title: 'FMX-R1',
    entries: []
  }
];

const defaultFibre: FibreSection[] = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map(letter => ({
  letter,
  entries: letter === 'A' ? [
    { id: generateId(), paires: '12', exA: 'EX-A1', numeroOdfA: 'ODF-001', etageA: 'RDC', exB: 'EX-B1', numeroOdfB: 'ODF-002', etageB: '1er', date: '2024-01-10', intervenant: 'Ahmed' }
  ] : []
}));

const defaultEnergie: EnergieSection[] = [
  {
    id: generateId(),
    type: 'GE',
    etat: [{ id: generateId(), marque: 'Caterpillar', dateMES: '2020-01-15', etat: 'Fonctionnel', observations: '' }],
    intervention: [{ id: generateId(), date: '2024-01-10', test: 'OK', index: '5000', batterie: 'OK', fuel: '80%', huile: 'OK', eau: 'OK', observations: '' }],
    derangement: []
  },
  {
    id: generateId(),
    type: 'CLIM',
    etat: [{ id: generateId(), marque: 'Carrier', dateMES: '2019-06-20', etat: 'Fonctionnel', observations: '' }],
    intervention: [],
    derangement: []
  },
  {
    id: generateId(),
    type: 'ONDULAIRE',
    etat: [{ id: generateId(), marque: 'APC', dateMES: '2021-03-10', etat: 'Fonctionnel', observations: '' }],
    intervention: [],
    derangement: []
  },
  {
    id: generateId(),
    type: 'BATTERIE',
    etat: [{ id: generateId(), marque: 'Yuasa', dateMES: '2022-01-05', etat: 'Bon', observations: '' }],
    intervention: [],
    derangement: []
  },
  {
    id: generateId(),
    type: 'ATELIER',
    etat: [{ id: generateId(), marque: 'Liebert', dateMES: '2018-11-20', etat: 'Fonctionnel', observations: '' }],
    intervention: [],
    derangement: []
  }
];

const defaultIntervenants: IntervenantEntry[] = [
  { id: generateId(), nom: 'Karim Saidi', service: 'Technique', natureIntervention: 'Installation', date: '2024-01-12', obs: '' },
];

const defaultVisiteurs: VisiteurEntry[] = [
  { id: generateId(), nom: 'Inspecteur A', structure: 'Ministère', natureVisite: 'Contrôle', date: '2024-01-20', obs: '' },
];

const defaultPersonnel: PersonnelEntry[] = [
  { id: generateId(), nom: 'Directeur Général', matricule: 'MAT-001', grade: 'Grade A', dateRecrutement: '2010-01-01', email: 'dg@company.com', adresse: 'Tunis', mobile: '20000000' },
];

const defaultFormations: FormationEntry[] = [
  { id: generateId(), nom: 'Ahmed Ben Ali', formation: 'Sécurité', date: '2024-02-01', lieu: 'Tunis', besoin: 'Certification' },
];

const defaultConges: PersonnelConge[] = [
  {
    id: generateId(),
    nom: 'Ahmed Ben Ali',
    conges: [
      { id: generateId(), dateDebut: '2024-07-01', dateFin: '2024-07-15', duree: '15', reste: '15', observations: 'Congé annuel' }
    ]
  }
];

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  
  // Répertoire
  const [repertoireLocal, setRepertoireLocal] = useState<RepertoireEntry[]>(() => {
    const saved = localStorage.getItem('repertoireLocal');
    return saved ? JSON.parse(saved) : defaultRepertoireLocal;
  });
  
  const [repertoireRegional, setRepertoireRegional] = useState<RepertoireEntry[]>(() => {
    const saved = localStorage.getItem('repertoireRegional');
    return saved ? JSON.parse(saved) : defaultRepertoireRegional;
  });
  
  const [entrepriseEntries, setEntrepriseEntries] = useState<EntrepriseEntry[]>(() => {
    const saved = localStorage.getItem('entrepriseEntries');
    return saved ? JSON.parse(saved) : defaultEntreprise;
  });
  
  // Boucle
  const [boucleLocal, setBoucleLocal] = useState<BoucleSection[]>(() => {
    const saved = localStorage.getItem('boucleLocal');
    return saved ? JSON.parse(saved) : defaultBoucleLocal;
  });
  
  const [boucleRegional, setBoucleRegional] = useState<BoucleSection[]>(() => {
    const saved = localStorage.getItem('boucleRegional');
    return saved ? JSON.parse(saved) : defaultBoucleRegional;
  });
  
  // FMX
  const [fmxLocal, setFmxLocal] = useState<FMXSection[]>(() => {
    const saved = localStorage.getItem('fmxLocal');
    return saved ? JSON.parse(saved) : defaultFmxLocal;
  });
  
  const [fmxRegional, setFmxRegional] = useState<FMXSection[]>(() => {
    const saved = localStorage.getItem('fmxRegional');
    return saved ? JSON.parse(saved) : defaultFmxRegional;
  });
  
  // Fibre
  const [fibreSections, setFibreSections] = useState<FibreSection[]>(() => {
    const saved = localStorage.getItem('fibreSections');
    return saved ? JSON.parse(saved) : defaultFibre;
  });
  
  // Énergie
  const [energieSections, setEnergieSections] = useState<EnergieSection[]>(() => {
    const saved = localStorage.getItem('energieSections');
    return saved ? JSON.parse(saved) : defaultEnergie;
  });
  
  // Visite
  const [intervenants, setIntervenants] = useState<IntervenantEntry[]>(() => {
    const saved = localStorage.getItem('intervenants');
    return saved ? JSON.parse(saved) : defaultIntervenants;
  });
  
  const [visiteurs, setVisiteurs] = useState<VisiteurEntry[]>(() => {
    const saved = localStorage.getItem('visiteurs');
    return saved ? JSON.parse(saved) : defaultVisiteurs;
  });
  
  // RH
  const [personnel, setPersonnel] = useState<PersonnelEntry[]>(() => {
    const saved = localStorage.getItem('personnel');
    return saved ? JSON.parse(saved) : defaultPersonnel;
  });
  
  const [formations, setFormations] = useState<FormationEntry[]>(() => {
    const saved = localStorage.getItem('formations');
    return saved ? JSON.parse(saved) : defaultFormations;
  });
  
  const [conges, setConges] = useState<PersonnelConge[]>(() => {
    const saved = localStorage.getItem('conges');
    return saved ? JSON.parse(saved) : defaultConges;
  });

  // Save to localStorage
  useEffect(() => { localStorage.setItem('repertoireLocal', JSON.stringify(repertoireLocal)); }, [repertoireLocal]);
  useEffect(() => { localStorage.setItem('repertoireRegional', JSON.stringify(repertoireRegional)); }, [repertoireRegional]);
  useEffect(() => { localStorage.setItem('entrepriseEntries', JSON.stringify(entrepriseEntries)); }, [entrepriseEntries]);
  useEffect(() => { localStorage.setItem('boucleLocal', JSON.stringify(boucleLocal)); }, [boucleLocal]);
  useEffect(() => { localStorage.setItem('boucleRegional', JSON.stringify(boucleRegional)); }, [boucleRegional]);
  useEffect(() => { localStorage.setItem('fmxLocal', JSON.stringify(fmxLocal)); }, [fmxLocal]);
  useEffect(() => { localStorage.setItem('fmxRegional', JSON.stringify(fmxRegional)); }, [fmxRegional]);
  useEffect(() => { localStorage.setItem('fibreSections', JSON.stringify(fibreSections)); }, [fibreSections]);
  useEffect(() => { localStorage.setItem('energieSections', JSON.stringify(energieSections)); }, [energieSections]);
  useEffect(() => { localStorage.setItem('intervenants', JSON.stringify(intervenants)); }, [intervenants]);
  useEffect(() => { localStorage.setItem('visiteurs', JSON.stringify(visiteurs)); }, [visiteurs]);
  useEffect(() => { localStorage.setItem('personnel', JSON.stringify(personnel)); }, [personnel]);
  useEffect(() => { localStorage.setItem('formations', JSON.stringify(formations)); }, [formations]);
  useEffect(() => { localStorage.setItem('conges', JSON.stringify(conges)); }, [conges]);

  const login = (username: string, password: string): boolean => {
    if (username === 'admin' && password === 'admin123') {
      setUser({ id: '1', username: 'admin', role: 'admin' });
      return true;
    } else if (username === 'user' && password === 'user123') {
      setUser({ id: '2', username: 'user', role: 'viewer' });
      return true;
    }
    return false;
  };

  const logout = () => setUser(null);

  return (
    <AppContext.Provider value={{
      user, login, logout, isAdmin: user?.role === 'admin',
      repertoireLocal, setRepertoireLocal,
      repertoireRegional, setRepertoireRegional,
      entrepriseEntries, setEntrepriseEntries,
      boucleLocal, setBoucleLocal,
      boucleRegional, setBoucleRegional,
      fmxLocal, setFmxLocal,
      fmxRegional, setFmxRegional,
      fibreSections, setFibreSections,
      energieSections, setEnergieSections,
      intervenants, setIntervenants,
      visiteurs, setVisiteurs,
      personnel, setPersonnel,
      formations, setFormations,
      conges, setConges,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
}
