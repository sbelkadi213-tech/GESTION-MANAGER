import { useState } from 'react';
import { useApp } from '../context/AppContext';

interface Column {
  key: string;
  label: string;
  editable?: boolean;
}

interface DataTableProps {
  columns: Column[];
  data: any[];
  onUpdate: (data: any[]) => void;
  searchPlaceholder?: string;
}

export default function DataTable({ columns, data, onUpdate, searchPlaceholder = 'Rechercher...' }: DataTableProps) {
  const { isAdmin } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValues, setEditValues] = useState<any>({});

  const filteredData = data.filter(item =>
    columns.some(col => 
      String(item[col.key] || '').toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  const handleEdit = (item: any) => {
    if (!isAdmin) return;
    setEditingId(item.id);
    setEditValues({ ...item });
  };

  const handleSave = () => {
    const updatedData = data.map(item =>
      item.id === editingId ? { ...editValues } : item
    );
    onUpdate(updatedData);
    setEditingId(null);
    setEditValues({});
  };

  const handleCancel = () => {
    setEditingId(null);
    setEditValues({});
  };

  const handleAdd = () => {
    if (!isAdmin) return;
    const newItem: any = { id: Math.random().toString(36).substr(2, 9) };
    columns.forEach(col => { newItem[col.key] = ''; });
    onUpdate([...data, newItem]);
    setEditingId(newItem.id);
    setEditValues(newItem);
  };

  const handleDelete = (id: string) => {
    if (!isAdmin) return;
    if (confirm('Êtes-vous sûr de vouloir supprimer cette entrée ?')) {
      onUpdate(data.filter(item => item.id !== id));
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 justify-between items-start sm:items-center">
        <div className="relative flex-1 w-full sm:max-w-md">
          <input
            type="text"
            placeholder={searchPlaceholder}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
          />
          <svg className="absolute left-3 top-3 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>
        {isAdmin && (
          <button
            onClick={handleAdd}
            className="flex items-center gap-2 px-4 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors shadow-sm"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Ajouter
          </button>
        )}
      </div>

      <div className="overflow-x-auto rounded-xl border border-gray-200 shadow-sm">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gradient-to-r from-gray-50 to-gray-100">
            <tr>
              {columns.map((col) => (
                <th key={col.key} className="px-4 py-3.5 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  {col.label}
                </th>
              ))}
              {isAdmin && (
                <th className="px-4 py-3.5 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Actions
                </th>
              )}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredData.length === 0 ? (
              <tr>
                <td colSpan={columns.length + (isAdmin ? 1 : 0)} className="px-4 py-8 text-center text-gray-500">
                  Aucune donnée disponible
                </td>
              </tr>
            ) : (
              filteredData.map((item, idx) => (
                <tr key={item.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'}>
                  {columns.map((col) => (
                    <td key={col.key} className="px-4 py-3 text-sm text-gray-700">
                      {editingId === item.id && col.editable !== false ? (
                        <input
                          type="text"
                          value={editValues[col.key] || ''}
                          onChange={(e) => setEditValues({ ...editValues, [col.key]: e.target.value })}
                          className="w-full px-2 py-1 border border-blue-300 rounded focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        />
                      ) : (
                        <span className="block max-w-xs truncate" title={String(item[col.key] || '-')}>
                          {item[col.key] || '-'}
                        </span>
                      )}
                    </td>
                  ))}
                  {isAdmin && (
                    <td className="px-4 py-3 text-sm whitespace-nowrap">
                      {editingId === item.id ? (
                        <div className="flex gap-2">
                          <button
                            onClick={handleSave}
                            className="px-3 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-xs font-medium transition-colors"
                          >
                            Enregistrer
                          </button>
                          <button
                            onClick={handleCancel}
                            className="px-3 py-1.5 bg-gray-500 text-white rounded-md hover:bg-gray-600 text-xs font-medium transition-colors"
                          >
                            Annuler
                          </button>
                        </div>
                      ) : (
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleEdit(item)}
                            className="px-3 py-1.5 bg-amber-500 text-white rounded-md hover:bg-amber-600 text-xs font-medium transition-colors"
                          >
                            Modifier
                          </button>
                          <button
                            onClick={() => handleDelete(item.id)}
                            className="px-3 py-1.5 bg-red-500 text-white rounded-md hover:bg-red-600 text-xs font-medium transition-colors"
                          >
                            Supprimer
                          </button>
                        </div>
                      )}
                    </td>
                  )}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      <div className="text-sm text-gray-500">
        {filteredData.length} résultat(s) sur {data.length} au total
      </div>
    </div>
  );
}
